import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'dart:html' as html;
import 'dart:typed_data';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../widgets/animated_icon_widget.dart';
import '../services/audio_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  ChatScreenState createState() => ChatScreenState();
}

class ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final FlutterTts _flutterTts = FlutterTts();
  final AudioService _audioService = AudioService();
  final stt.SpeechToText _speechToText = stt.SpeechToText();
  final List<Map<String, dynamic>> _messages = [];
  bool _isSpeaking = false;
  bool _isRecording = false;
  Uint8List? _recordedData;
  String _transcribedText = '';

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  // Initialize permissions for microphone access
  Future<void> _initialize() async {
    final micPermission = await html.window.navigator.permissions?.query({'name': 'microphone'});
    if (micPermission != null && micPermission.state == 'granted') {
      debugPrint("Microphone permission granted");
    } else {
      debugPrint("Microphone permission denied");
    }
  }

  @override
  void dispose() {
    _flutterTts.stop();
    _controller.dispose();
    super.dispose();
  }

  // Send a text message
  void _sendMessage() {
    if (_controller.text.isEmpty) return;

    setState(() {
      _messages.add({
        'text': _controller.text,
        'isBot': false,
        'type': 'text',
      });
    });

    _controller.clear();
    _sendBotResponse('Response from bot');
  }

  // Send the recorded voice message and text for assessment
  Future<void> _sendVoiceMessage() async {
    if (_recordedData == null && _transcribedText.isEmpty) {
      debugPrint("No recorded data or transcribed text to send.");
      return;
    }

    // Call the pronunciation assessment API
    final response = await _assessPronunciation(_recordedData!, _transcribedText);

    if (response == null) {
      debugPrint("Pronunciation assessment failed.");
      return;
    }

    setState(() {
      if (_recordedData != null) {
        _messages.add({
          'text': 'Voice message sent',
          'isBot': false,
          'type': 'audio',
          'data': _recordedData,
        });
        debugPrint("Voice message added to messages list.");
      }

      if (_transcribedText.isNotEmpty) {
        _messages.add({
          'text': _transcribedText,
          'isBot': false,
          'type': 'text',
        });
        debugPrint("Transcribed text message added to messages list.");
      }

      _messages.add({
        'text': response['RecognizedText'],
        'isBot': true,
        'type': 'assessment',
        'assessment': response,
      });
      debugPrint("Assessment result added to messages list.");

      _recordedData = null;  // Remove recording after sending
      _transcribedText = '';  // Clear transcribed text after sending
    });

    _sendBotResponse('Bot received your voice message');
  }

  // Send the recorded data and text to the pronunciation assessment API
  Future<Map<String, dynamic>?> _assessPronunciation(Uint8List audioData, String text) async {
    final uri = Uri.parse('https://localhost:7244/api/PronunciationAssessment/assessment'); // Update URL
    final request = http.MultipartRequest('POST', uri)
      ..fields['ReferenceText'] = text
      ..files.add(http.MultipartFile.fromBytes('AudioFile', audioData, filename: 'audio.webm'));

    try {
      final response = await request.send();

      if (response.statusCode == 200) {
        final responseBody = await response.stream.bytesToString();
        return json.decode(responseBody);
      } else {
        final responseBody = await response.stream.bytesToString();
        debugPrint('Failed to assess pronunciation: ${response.statusCode}');
        debugPrint('Response body: $responseBody');
        return null;
      }
    } catch (e) {
      debugPrint('Error during pronunciation assessment: $e');
      return null;
    }
  }

  // Handle bot response
  void _sendBotResponse(String response) async {
    setState(() {
      _messages.add({
        'text': response,
        'isBot': true,
        'type': 'text',
      });
      _isSpeaking = true;
    });

    await _flutterTts.speak(response);

    setState(() {
      _isSpeaking = false;
    });
  }

  // Start recording audio and transcription
  Future<void> _startRecording() async {
    if (!_isRecording) {
      await _audioService.startRecording();
      bool available = await _speechToText.initialize();
      if (available) {
        _speechToText.listen(onResult: (result) {
          setState(() {
            _transcribedText = result.recognizedWords;
          });
        });
      }
      setState(() {
        _isRecording = true;
      });
      debugPrint("Recording and transcription started...");
    }
  }

  // Stop recording audio and transcription
  Future<void> _stopRecording() async {
    if (_isRecording) {
      _recordedData = await _audioService.stopRecording();
      _speechToText.stop();
      setState(() {
        _isRecording = false;
      });
      debugPrint("Recording stopped, data size: ${_recordedData?.length}");
      debugPrint("Transcribed text: $_transcribedText");
    }
  }

  // Play the recorded audio
  void _playAudio(Uint8List data) {
    final blob = html.Blob([data]);
    final url = html.Url.createObjectUrlFromBlob(blob);
    final audioElement = html.AudioElement(url)
      ..autoplay = true
      ..onEnded.listen((event) {
        html.Url.revokeObjectUrl(url);
        debugPrint("Audio playback finished.");
      });
    audioElement.play().then((_) {
      debugPrint("Audio playback started.");
    }).catchError((error) {
      debugPrint("Error during audio playback: $error");
    });
  }

  // Build the message widget based on its type
  Widget _buildMessage(Map<String, dynamic> message) {
    bool isBot = message['isBot'];
    String messageType = message['type'];

    return Align(
      alignment: isBot ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 8.0),
        padding: const EdgeInsets.all(10.0),
        decoration: BoxDecoration(
          color: isBot ? Colors.grey[300] : Colors.blue[300],
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: messageType == 'text'
            ? Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (isBot) AnimatedIconWidget(isSpeaking: _isSpeaking),
                  const SizedBox(width: 8.0),
                  Flexible(child: Text(message['text'])),
                ],
              )
            : messageType == 'audio'
                ? IconButton(
                    icon: const Icon(Icons.play_arrow),
                    onPressed: () => _playAudio(message['data']),
                  )
                : messageType == 'assessment'
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(message['text']),
                          Text('Pronunciation Score: ${message['assessment']['PronunciationScore']}'),
                          // Add more graphical representation here
                        ],
                      )
                    : Container(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chat Screen'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return _buildMessage(_messages[index]);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(hintText: 'Enter your message'),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
                IconButton(
                  icon: Icon(_isRecording ? Icons.stop : Icons.mic),
                  onPressed: _isRecording ? _stopRecording : _startRecording,
                ),
                IconButton(
                  icon: const Icon(Icons.audiotrack),
                  onPressed: _sendVoiceMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
